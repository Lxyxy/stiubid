export default {
  namespace: 'app',
  state: {},
  subscriptions: {},
  effects: {},
  reducers: {}
}
