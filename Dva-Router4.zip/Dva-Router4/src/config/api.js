export default {
  demo: '/demo'
}
